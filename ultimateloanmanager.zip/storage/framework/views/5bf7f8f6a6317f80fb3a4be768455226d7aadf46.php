<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.detail',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-widget">
        <div class="box-header with-border">
            <div class="row">
                <div class="col-sm-3">
                    <div class="user-block">
                        <img class="img-circle"
                             src="<?php echo e(asset('assets/dist/img/user.png')); ?>"
                             alt="user image"/>
                            <span class="username">
                                <?php echo e($loan->borrower->title); ?>

                                . <?php echo e($loan->borrower->first_name); ?> <?php echo e($loan->borrower->last_name); ?>

                            </span>
                            <span class="description" style="font-size:13px; color:#000000"><?php echo e($loan->borrower->unique_number); ?>

                                <br>
                                <?php if(Sentinel::hasAccess('borrowers.create')): ?>
                                    <a href="<?php echo e(url('borrower/'.$loan->borrower->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?></a>
                                    <br>
                                <?php endif; ?>
                                <?php echo e($loan->borrower->business_name); ?>, <?php echo e($loan->borrower->working_status); ?>

                                <br><?php echo e($loan->borrower->gender); ?>

                                , <?php echo e(date("Y-m-d")-$loan->borrower->dob); ?> <?php echo e(trans_choice('general.year',2)); ?>

                            </span>
                    </div>
                    <!-- /.user-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3">
                    <ul class="list-unstyled">
                        <li><b><?php echo e(trans_choice('general.address',1)); ?>:</b> <?php echo e($loan->borrower->address); ?></li>
                        <li><b><?php echo e(trans_choice('general.city',1)); ?>:</b> <?php echo e($loan->borrower->city); ?></li>
                        <li><b><?php echo e(trans_choice('general.state',1)); ?>:</b> <?php echo e($loan->borrower->state); ?></li>
                        <li><b><?php echo e(trans_choice('general.zip',1)); ?>:</b> <?php echo e($loan->borrower->zip); ?></li>

                        <a data-toggle="collapse" data-parent="#accordion" href="#viewFiles">
                            <?php echo e(trans_choice('general.view',1)); ?> <?php echo e(trans_choice('general.borrower',1)); ?> <?php echo e(trans_choice('general.file',2)); ?>

                        </a>

                        <div id="viewFiles" class="panel-collapse collapse">
                            <div class="box-body">
                                <ul class="no-margin" style="font-size:12px; padding-left:10px">

                                    <?php foreach(unserialize($loan->borrower->files) as $key=>$value): ?>
                                        <li><a href="<?php echo asset('uploads/'.$value); ?>"
                                               target="_blank"><?php echo $value; ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <ul class="list-unstyled">
                        <li><b><?php echo e(trans_choice('general.phone',1)); ?>:</b> <?php echo e($loan->borrower->phone); ?></li>
                        <li>
                            <b><?php echo e(trans_choice('general.email',1)); ?>:</b>
                            <a
                                    onclick="javascript:window.open('mailto:<?php echo e($loan->borrower->email); ?>', 'mail');event.preventDefault()"
                                    href="mailto:<?php echo e($loan->borrower->email); ?>"><?php echo e($loan->borrower->email); ?></a>
                            <?php if(Sentinel::hasAccess('communication.create')): ?>
                                <div class="btn-group-horizontal"><a type="button" class="btn-xs bg-red"
                                                                     href="<?php echo e(url('communication/email/create?borrower_id='.$loan->borrower->id)); ?>"><?php echo e(trans_choice('general.send',1)); ?>

                                        <?php echo e(trans_choice('general.email',1)); ?></a></div>
                            <?php endif; ?>
                        </li>
                        <li><b>Mobile:</b> <?php echo e($loan->borrower->mobile); ?>

                            <?php if(Sentinel::hasAccess('communication.create')): ?>
                                <div class="btn-group-horizontal"><a type="button" class="btn-xs bg-red"
                                                                     href="<?php echo e(url('communication/sms/create?borrower_id='.$loan->borrower->id)); ?>"><?php echo e(trans_choice('general.send',1)); ?>

                                        <?php echo e(trans_choice('general.sms',1)); ?></a></div>
                            <?php endif; ?>
                        </li>

                    </ul>
                </div>
                <div class="col-sm-3">
                    <ul class="list-unstyled">
                        <li><b><?php echo e(trans_choice('general.custom_field',2)); ?></b></li>
                        <?php foreach($custom_fields as $key): ?>
                            <li>
                                <?php if(!empty($key->custom_field)): ?>
                                    <strong><?php echo e($key->custom_field->name); ?>:</strong>
                                <?php endif; ?>
                                <?php echo e($key->name); ?>

                            </li>
                        <?php endforeach; ?>

                    </ul>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-sm-9">
                    <div class="btn-group-horizontal">
                        <?php if(Sentinel::hasAccess('loan.create')): ?>
                            <a type="button" class="btn bg-olive margin"
                               href="<?php echo e(url('loan/create?borrower_id='.$loan->borrower_id)); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                                <?php echo e(trans_choice('general.loan',1)); ?></a>
                        <?php endif; ?>
                        <a type="button" class="btn bg-navy margin"
                           href="<?php echo e(url('loan/data')); ?>"><?php echo e(trans_choice('general.view',1)); ?>

                            <?php echo e(trans_choice('general.loan',2)); ?></a>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="pull-left">
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-info dropdown-toggle margin" data-toggle="dropdown">
                                <?php echo e(trans_choice('general.borrower',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?>

                                <span class="fa fa-caret-down"></span></button>
                            <ul class="dropdown-menu" role="menu">

                                <li>
                                    <a href="<?php echo e(url('loan/'.$loan->borrower_id.'/borrower_statement/print')); ?>"
                                       target="_blank"><?php echo e(trans_choice('general.print',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('loan/'.$loan->borrower_id.'/borrower_statement/pdf')); ?>"
                                       target="_blank"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.in',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('loan/'.$loan->borrower_id.'/borrower_statement/email')); ?>"
                                            ><?php echo e(trans_choice('general.email',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?></a>
                                </li>
                                <li>
                                    <!--<li>
                                    <a href="<?php echo e(url('loan/'.$loan->borrower_id.'/borrower_statement/excel')); ?>"
                                       target="_blank">Download in Excel</a></li>

                                <li>
                                    <a href="<?php echo e(url('loan/'.$loan->borrower_id.'/borrower_statement/csv')); ?>"
                                       target="_blank">Download in CSV</a></li>-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($loan->borrower->blacklisted==1): ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-danger"><?php echo e(trans_choice('general.blacklist_notification',1)); ?></div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" || $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
        <div class="box box-info">
            <div class="box-body table-responsive no-padding">
                <table id="" class="table table-bordered table-condensed table-hover">
                    <thead>
                    <tr style="background-color: #D1F9FF">
                        <th><?php echo e(trans_choice('general.loan',1)); ?>#</th>
                        <th><?php echo e(trans_choice('general.released',1)); ?></th>
                        <th><?php echo e(trans_choice('general.maturity',1)); ?></th>
                        <th><?php echo e(trans_choice('general.repayment',1)); ?></th>
                        <th><?php echo e(trans_choice('general.principal',1)); ?></th>
                        <th><?php echo e(trans_choice('general.interest',1)); ?>%</th>
                        <th><?php echo e(trans_choice('general.interest',1)); ?></th>
                        <th><?php echo e(trans_choice('general.fee',2)); ?></th>
                        <th><?php echo e(trans_choice('general.penalty',1)); ?></th>
                        <th><?php echo e(trans_choice('general.due',1)); ?></th>
                        <th><?php echo e(trans_choice('general.paid',1)); ?></th>
                        <th><?php echo e(trans_choice('general.balance',1)); ?></th>
                        <th><?php echo e(trans_choice('general.status',1)); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo e($loan->id); ?></td>
                        <td><?php echo e($loan->release_date); ?></td>
                        <td><?php echo e($loan->maturity_date); ?></td>
                        <td>
                            <?php if($loan->repayment_cycle=='daily'): ?>
                                <?php echo e(trans_choice('general.daily',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='weekly'): ?>
                                <?php echo e(trans_choice('general.weekly',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='monthly'): ?>
                                <?php echo e(trans_choice('general.monthly',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='bi_monthly'): ?>
                                <?php echo e(trans_choice('general.bi_monthly',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='quarterly'): ?>
                                <?php echo e(trans_choice('general.quarterly',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='semi_annual'): ?>
                                <?php echo e(trans_choice('general.semi_annually',1)); ?>

                            <?php endif; ?>
                            <?php if($loan->repayment_cycle=='annually'): ?>
                                <?php echo e(trans_choice('general.annual',1)); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e(round($loan->principal,2)); ?></td>
                        <td>  <?php echo e(round($loan->interest_rate,2)); ?>%/<?php echo e($loan->interest_period); ?></td>
                        <td><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_interest($loan->id),2)); ?></td>
                        <td><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_fees($loan->id),2)); ?></td>
                        <td><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_penalty($loan->id),2)); ?></td>
                        <td>
                            <?php if($loan->override==1): ?>
                                <s><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id),2)); ?></s><br>
                                <?php echo e(round($loan->balance,2)); ?>

                            <?php else: ?>
                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id),2)); ?>

                            <?php endif; ?>
                            <br>
                            <small>
                                <a href="<?php echo e(url('loan/'.$loan->id.'/override')); ?>"><?php echo e(trans_choice('general.override',1)); ?></a>
                            </small>
                        </td>
                        <td><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_paid($loan->id),2)); ?></td>
                        <td><?php echo e(round(\App\Helpers\GeneralHelper::loan_total_balance($loan->id),2)); ?></td>
                        <td>
                            <?php if($loan->maturity_date<date("Y-m-d") && \App\Helpers\GeneralHelper::loan_total_balance($loan->id)>0): ?>
                                <span class="label label-danger"><?php echo e(trans_choice('general.past_maturity',1)); ?></span>
                            <?php else: ?>
                                <?php if($loan->status=='pending'): ?>
                                    <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='approved'): ?>
                                    <span class="label label-info"><?php echo e(trans_choice('general.awaiting',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='disbursed'): ?>
                                    <span class="label label-info"><?php echo e(trans_choice('general.active',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='declined'): ?>
                                    <span class="label label-danger"><?php echo e(trans_choice('general.declined',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='withdrawn'): ?>
                                    <span class="label label-danger"><?php echo e(trans_choice('general.withdrawn',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='written_off'): ?>
                                    <span class="label label-danger"><?php echo e(trans_choice('general.written_off',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='closed'): ?>
                                    <span class="label label-success"><?php echo e(trans_choice('general.closed',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='pending_reschedule'): ?>
                                    <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.reschedule',1)); ?></span>
                                <?php endif; ?>
                                <?php if($loan->status=='rescheduled'): ?>
                                    <span class="label label-info"><?php echo e(trans_choice('general.rescheduled',1)); ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" || $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
                        <li class=""><a href="#repayments" data-toggle="tab"
                                        aria-expanded="true"><?php echo e(trans_choice('general.repayment',2)); ?></a></li>
                        <li><a href="#loan_schedule" data-toggle="tab"
                               aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?>

                                <?php echo e(trans_choice('general.schedule',1)); ?></a></li>
                        <li class=""><a href="#pending_dues" data-toggle="tab"
                                        aria-expanded="false"><?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.due',2)); ?></a>
                        </li>

                    <?php endif; ?>
                    <li class="active"><a href="#loan_terms" data-toggle="tab"
                                          aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.term',2)); ?></a>
                    </li>

                    <li class=""><a href="#loan_collateral" data-toggle="tab"
                                    aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.collateral',1)); ?></a>
                    </li>
                    <li class=""><a href="#loan_guarantors" data-toggle="tab"
                                    aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.guarantor',2)); ?></a>
                    </li>
                    <li class=""><a href="#loan_files" data-toggle="tab"
                                    aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.file',2)); ?></a>
                    </li>
                    <li class=""><a href="#loan_comments" data-toggle="tab"
                                    aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.comment',2)); ?></a>
                    </li>

                </ul>
                <div class="tab-content">
                    <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" || $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
                        <div class="tab-pane " id="repayments">
                            <div class="btn-group-horizontal">
                                <?php if(Sentinel::hasAccess('repayments.create')): ?>
                                    <a type="button" class="btn bg-gray margin"
                                       href="<?php echo e(url('loan/'.$loan->id.'/repayment/create')); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                                        <?php echo e(trans_choice('general.repayment',1)); ?></a>
                                <?php endif; ?>
                            </div>
                            <div class="box box-info">
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="table-responsive">
                                                <table id="view-repayments"
                                                       class="table table-bordered table-condensed table-hover dataTable no-footer">
                                                    <thead>
                                                    <tr style="background-color: #D1F9FF" role="row">
                                                        <th>
                                                            <?php echo e(trans_choice('general.collection',1)); ?> <?php echo e(trans_choice('general.date',1)); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans_choice('general.collected_by',1)); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans_choice('general.method',1)); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans_choice('general.amount',1)); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans_choice('general.action',1)); ?>

                                                        </th>
                                                        <th>
                                                            <?php echo e(trans_choice('general.receipt',1)); ?>

                                                        </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach($payments as $key): ?>
                                                        <tr>
                                                            <td><?php echo e($key->collection_date); ?></td>
                                                            <td>
                                                                <?php if(!empty($key->user)): ?>
                                                                    <?php echo e($key->user->first_name); ?> <?php echo e($key->user->last_name); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if(!empty($key->loan_repayment_method)): ?>
                                                                    <?php echo e($key->loan_repayment_method->name); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                            <td>$<?php echo e(round($key->amount,2)); ?></td>
                                                            <td>
                                                                <div class="btn-group-horizontal">
                                                                    <?php if(Sentinel::hasAccess('repayments.update')): ?>
                                                                        <a type="button"
                                                                           class="btn bg-white btn-xs text-bold"
                                                                           href="<?php echo e(url('loan/'.$loan->id.'/repayment/'.$key->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?></a>
                                                                    <?php endif; ?>
                                                                    <?php if(Sentinel::hasAccess('repayments.delete')): ?>
                                                                        <a type="button"
                                                                           class="btn bg-white btn-xs text-bold deletePayment"
                                                                           href="<?php echo e(url('loan/'.$loan->id.'/repayment/'.$key->id.'/delete')); ?>"
                                                                                ><?php echo e(trans_choice('general.delete',1)); ?></a>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <a type="button" class="btn btn-default btn-xs"
                                                                   href="<?php echo e(url('loan/'.$loan->id.'/repayment/'.$key->id.'/print')); ?>"
                                                                   target="_blank">
                                                                <span class="glyphicon glyphicon-print"
                                                                      aria-hidden="true"></span>
                                                                </a>
                                                                <a type="button" class="btn btn-default btn-xs"
                                                                   href="<?php echo e(url('loan/'.$loan->id.'/repayment/'.$key->id.'/pdf')); ?>"
                                                                   target="_blank">
                                                                <span class="glyphicon glyphicon-file"
                                                                      aria-hidden="true"></span>
                                                                </a>
                                                                <?php if(Sentinel::hasAccess('communication.create')): ?>
                                                                    <a type="button" class="btn btn-default btn-xs"
                                                                       href="<?php echo e(url('loan/'.$loan->id.'/repayment/'.$key->id.'/email')); ?>"
                                                                       target="_blank">
                                                                <span class="glyphicon glyphicon-envelope"
                                                                      aria-hidden="true"></span>
                                                                    </a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.tab-pane -->

                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="loan_schedule">
                            <div class="row">
                                <div class="col-sm-3">

                                    <div class="input-group-btn">
                                        <button type="button" class="btn btn-info dropdown-toggle margin"
                                                data-toggle="dropdown"
                                                aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.schedule',1)); ?>

                                            <span class="fa fa-caret-down"></span></button>
                                        <ul class="dropdown-menu" role="menu">
                                            <li>
                                                <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/print')); ?>"
                                                   target="_blank"><?php echo e(trans_choice('general.print',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/pdf')); ?>"
                                                   target="_blank"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.in',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?></a>
                                            </li>
                                            <?php if(Sentinel::hasAccess('communication.create')): ?>
                                                <li>
                                                    <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/email')); ?>"
                                                            ><?php echo e(trans_choice('general.email',1)); ?> <?php echo e(trans_choice('general.schedule',1)); ?></a>
                                                </li>
                                                <?php endif; ?>
                                                        <!--<li>
                                            <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/excel')); ?>"
                                               target="_blank">Download in Excel</a></li>

                                        <li>
                                            <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/csv')); ?>"
                                               target="_blank">Download in CSV</a></li>-->
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-sm-9 pull-right">
                                    <div class="btn-group-horizontal">
                                        <a type="button" class="btn bg-gray margin"
                                           href="<?php echo e(url('loan/'.$loan->id.'/schedule/print')); ?>"
                                           target="_blank"><?php echo e(trans_choice('general.print',1)); ?> <?php echo e(trans_choice('general.schedule',1)); ?></a>
                                        <?php if(Sentinel::hasAccess('loans.update')): ?>
                                            <a type="button" class="btn bg-gray margin"
                                               href="<?php echo e(url('loan/'.$loan->id.'/schedule/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?>

                                                <?php echo e(trans_choice('general.schedule',1)); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="box box-success">
                                <div class="box-body table-responsive no-padding">
                                    <table class="table table-bordered table-condensed table-hover">
                                        <tbody>
                                        <tr style="background-color: #F2F8FF">
                                            <th style="width: 10px">
                                                <b>#</b>
                                            </th>
                                            <th>
                                                <b><?php echo e(trans_choice('general.date',1)); ?></b>
                                            </th>
                                            <th>
                                                <b><?php echo e(trans_choice('general.description',1)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <b><?php echo e(trans_choice('general.principal',1)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <b><?php echo e(trans_choice('general.interest',1)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <b><?php echo e(trans_choice('general.fee',2)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <b><?php echo e(trans_choice('general.penalty',1)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <b><?php echo e(trans_choice('general.due',1)); ?></b>
                                            </th>
                                            <th style="text-align:right;">
                                                <?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                                            </th>
                                            <th style="text-align:right;">
                                                <?php echo e(trans_choice('general.paid',1)); ?>

                                            </th>
                                            <th style="text-align:right;">
                                                <?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                                            </th>
                                            <th style="text-align:right;">
                                                <?php echo e(trans_choice('general.principal',1)); ?> <?php echo e(trans_choice('general.balance',1)); ?> <?php echo e(trans_choice('general.owed',1)); ?>

                                            </th>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Models\LoanSchedule::where('loan_id',
                                                $loan->id)->sum('principal'),2)); ?>

                                            </td>
                                        </tr>
                                        <?php
                                        $count = 1;
                                        $total_due = 0;
                                        $principal_balance = \App\Models\LoanSchedule::where('loan_id',
                                                $loan->id)->sum('principal');
                                        foreach ($schedules as $schedule) {
                                        $principal_balance = $principal_balance - $schedule->principal;
                                        if ($count == 1) {
                                            $total_due = ($schedule->principal + $schedule->interest + $schedule->fees + $schedule->penalty);

                                        } else {
                                            $total_due = $total_due + ($schedule->principal + $schedule->interest + $schedule->fees + $schedule->penalty);
                                        }
                                        ?>
                                        <tr class="<?php if((($schedule->principal+$schedule->interest+$schedule->fees+$schedule->penalty)-\App\Models\LoanRepayment::where('loan_id',$loan->id)->where('due_date',$schedule->due_date)->sum('amount'))<=0): ?> success <?php endif; ?>">
                                            <td>
                                                <?php echo e($count); ?>

                                            </td>
                                            <td>
                                                <?php echo e($schedule->due_date); ?>

                                            </td>
                                            <td>
                                                <?php echo e($schedule->description); ?>

                                            </td>
                                            <td style="text-align:right">
                                                <?php echo e(round($schedule->principal,2)); ?>

                                            </td>
                                            <td style="text-align:right">
                                                <?php echo e(round($schedule->interest,2)); ?>

                                            </td>
                                            <td style="text-align:right">
                                                <?php echo e(round($schedule->fees,2)); ?>

                                            </td>
                                            <td style="text-align:right">
                                                <?php echo e(round($schedule->penalty,2)); ?>

                                            </td>
                                            <td style="text-align:right; font-weight:bold">
                                                <?php echo e(round(($schedule->principal+$schedule->interest+$schedule->fees+$schedule->penalty),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round($total_due,2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Models\LoanRepayment::where('loan_id',$loan->id)->where('due_date',$schedule->due_date)->sum('amount'),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round((($schedule->principal+$schedule->interest+$schedule->fees+$schedule->penalty)-\App\Models\LoanRepayment::where('loan_id',$loan->id)->where('due_date',$schedule->due_date)->sum('amount')),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round($principal_balance,2)); ?>

                                            </td>
                                        </tr>
                                        <?php
                                        $count++;
                                        }
                                        ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td style="font-weight:bold"><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.due',1)); ?></td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_principal($loan->id),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_interest($loan->id),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_fees($loan->id),2)); ?>

                                            </td>
                                            <td style="text-align:right;">
                                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_penalty($loan->id),2)); ?>

                                            </td>
                                            <td style="text-align:right; font-weight:bold">
                                                <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id),2)); ?>

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="pending_dues">
                            <div class="tab_content">
                                <p><?php echo e(trans_choice('general.pending_due_msg',1)); ?></p>

                                <div class="box box-success">
                                    <div class="box-body table-responsive no-padding">
                                        <table class="table table-bordered table-condensed table-hover">
                                            <tbody>
                                            <tr style="background-color: #F2F8FF">
                                                <th width="200">
                                                    <b><?php echo e(trans_choice('general.based_on',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.term',2)); ?>

                                                        :</b>
                                                </th>
                                                <th style="text-align:right;">
                                                    <b><?php echo e(trans_choice('general.principal',1)); ?></b>
                                                </th>
                                                <th style="text-align:right;">
                                                    <b><?php echo e(trans_choice('general.interest',1)); ?></b>
                                                </th>
                                                <th style="text-align:right;">
                                                    <b><?php echo e(trans_choice('general.fee',2)); ?></b>
                                                </th>
                                                <th style="text-align:right;">
                                                    <b><?php echo e(trans_choice('general.penalty',1)); ?></b>
                                                </th>
                                                <th style="text-align:right;">
                                                    <b><?php echo e(trans_choice('general.total',1)); ?></b>
                                                </th>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-red">
                                                    <?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_principal($loan->id),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_interest($loan->id),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_fees($loan->id),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_penalty($loan->id),2)); ?>

                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id),2)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-green">
                                                    <?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.paid',1)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'principal'),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'interest'),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'fees'),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'penalty'),2)); ?>

                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_paid($loan->id),2)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-gray">
                                                    <?php echo e(trans_choice('general.balance',1)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_principal($loan->id)-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'principal')),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_interest($loan->id)-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'interest')),2)); ?>


                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_fees($loan->id)-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'fees')),2)); ?>


                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_penalty($loan->id)-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'penalty')),2)); ?>


                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id)-\App\Helpers\GeneralHelper::loan_total_paid($loan->id)),2)); ?>


                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="6">
                                                    <br><br><b><?php echo e(trans_choice('general.based_on',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.schedule',1)); ?>

                                                        :</b></td>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-red">
                                                    <?php echo e(trans_choice('general.due',1)); ?>

                                                    <?php echo e(trans_choice('general.till',1)); ?> <?php echo e(\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_principal($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_interest($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_fees($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_penalty($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-green">
                                                    <?php echo e(trans_choice('general.paid',1)); ?>

                                                    <?php echo e(trans_choice('general.till',1)); ?> <?php echo e(\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'principal',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'interest',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'fees',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'penalty',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round(\App\Helpers\GeneralHelper::loan_total_paid($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))),2)); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-bold bg-gray">
                                                    <?php echo e(trans_choice('general.balance',1)); ?>

                                                    <?php echo e(trans_choice('general.till',1)); ?> <?php echo e(\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d"))); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_principal($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'principal',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))),2)); ?>

                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_interest($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'interest',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))),2)); ?>


                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_fees($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'fees',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))),2)); ?>


                                                </td>
                                                <td style="text-align:right">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_penalty($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))-\App\Helpers\GeneralHelper::loan_paid_item($loan->id,'penalty',\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))),2)); ?>


                                                </td>
                                                <td style="text-align:right; font-weight:bold">
                                                    <?php echo e(round((\App\Helpers\GeneralHelper::loan_total_due_amount($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))-\App\Helpers\GeneralHelper::loan_total_paid($loan->id,\App\Helpers\GeneralHelper::determine_due_date($loan->id,date("Y-m-d")))),2)); ?>


                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="tab-pane active" id="loan_terms">
                        <div class="row">
                            <div class="col-sm-8">
                                <?php if($loan->status=='pending'): ?>
                                    <div class="col-sm-6">
                                        <?php if(Sentinel::hasAccess('loans.approve')): ?>
                                            <button type="button" class="btn btn-success margin"
                                                    data-toggle="modal"
                                                    data-target="#approveLoan"><?php echo e(trans_choice('general.approve',1)); ?></button>
                                            <button type="button" class="btn btn-danger margin"
                                                    data-toggle="modal"
                                                    data-target="#declineLoan"><?php echo e(trans_choice('general.decline',1)); ?></button>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($loan->status=='declined'): ?>
                                    <div class="col-sm-6">
                                        <?php if(Sentinel::hasAccess('loans.approve')): ?>
                                            <button type="button" class="btn btn-success margin"
                                                    data-toggle="modal"
                                                    data-target="#approveLoan"><?php echo e(trans_choice('general.approve',1)); ?></button>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($loan->status=='approved'): ?>
                                    <div class="col-sm-6">
                                        <?php if(Sentinel::hasAccess('loans.disburse')): ?>
                                            <button type="button" class="btn btn-success margin"
                                                    data-toggle="modal"
                                                    data-target="#disburseLoan"><?php echo e(trans_choice('general.disburse',1)); ?></button>
                                            <a type="button" class="btn btn-danger  delete margin"
                                               href="<?php echo e(url('loan/'.$loan->id.'/unapprove')); ?>"><?php echo e(trans_choice('general.undo',1)); ?> <?php echo e(trans_choice('general.approval',1)); ?></a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($loan->status=='written_off'): ?>
                                    <div class="col-sm-6">
                                        <?php if(Sentinel::hasAccess('loans.writeoff')): ?>
                                            <a type="button" class="btn btn-danger  delete margin"
                                               href="<?php echo e(url('loan/'.$loan->id.'/unwrite_off')); ?>"><?php echo e(trans_choice('general.undo',1)); ?> <?php echo e(trans_choice('general.write_off',1)); ?></a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($loan->status=='withdrawn'): ?>
                                    <div class="col-sm-6">
                                        <?php if(Sentinel::hasAccess('loans.withdraw')): ?>
                                            <a type="button" class="btn btn-danger  delete margin"
                                               href="<?php echo e(url('loan/'.$loan->id.'/unwithdraw')); ?>"><?php echo e(trans_choice('general.undo',1)); ?> <?php echo e(trans_choice('general.withdrawal',1)); ?></a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if($loan->status=='disbursed'): ?>
                                    <div class="col-sm-3">
                                        <div class="btn-group-horizontal">
                                            <?php if(Sentinel::hasAccess('loans.disburse')): ?>
                                                <a type="button" class="btn btn-danger delete margin"
                                                   href="<?php echo e(url('loan/'.$loan->id.'/undisburse')); ?>"
                                                        ><?php echo e(trans_choice('general.undo',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group-btn">
                                            <button type="button" class="btn btn-info dropdown-toggle margin"
                                                    data-toggle="dropdown"
                                                    aria-expanded="false"><?php echo e(trans_choice('general.more_action',1)); ?>

                                                <span class="fa fa-caret-down"></span></button>
                                            <ul class="dropdown-menu" role="menu">
                                                <?php if(Sentinel::hasAccess('loans.withdraw')): ?>
                                                    <li>
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#withdrawLoan"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></a>
                                                    </li>
                                                <?php endif; ?>
                                                <?php if(Sentinel::hasAccess('loans.writeoff')): ?>
                                                    <li>
                                                        <a href="#" class=""
                                                           data-toggle="modal"
                                                           data-target="#writeoffLoan"><?php echo e(trans_choice('general.write_off',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></a>
                                                    </li>
                                                <?php endif; ?>
                                                <?php if(Sentinel::hasAccess('loans.reschedule')): ?>
                                                    <li>
                                                        <a href="#"
                                                           class=""
                                                           data-toggle="modal"
                                                           data-target="#rescheduleLoan"><?php echo e(trans_choice('general.reschedule',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></a>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" || $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
                                    <div class="col-sm-3">
                                        <div class="input-group-btn">
                                            <button type="button" class="btn btn-info dropdown-toggle margin"
                                                    data-toggle="dropdown"
                                                    aria-expanded="false"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.schedule',1)); ?>

                                                <span class="fa fa-caret-down"></span></button>
                                            <ul class="dropdown-menu" role="menu">

                                                <li>
                                                    <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/print')); ?>"
                                                       target="_blank"><?php echo e(trans_choice('general.print',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?></a>
                                                </li>

                                                <li>
                                                    <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/pdf')); ?>"
                                                       target="_blank"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.in',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?></a>
                                                </li>
                                                <?php if(Sentinel::hasAccess('communication.create')): ?>
                                                    <li>
                                                        <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/email')); ?>"
                                                                ><?php echo e(trans_choice('general.email',1)); ?> <?php echo e(trans_choice('general.statement',1)); ?></a>
                                                    </li>
                                                    <?php endif; ?>
                                                            <!--<li>
                                            <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/excel')); ?>"
                                               target="_blank">Download in Excel</a></li>

                                        <li>
                                            <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/csv')); ?>"
                                               target="_blank">Download in CSV</a></li>-->

                                            </ul>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="col-sm-4 pull-right">
                                <div class="btn-group-horizontal">
                                    <?php if(Sentinel::hasAccess('loans.update')): ?>
                                        <a type="button" class="btn bg-gray margin"
                                           href="<?php echo e(url('loan/'.$loan->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?>

                                            <?php echo e(trans_choice('general.loan',1)); ?></a>
                                    <?php endif; ?>

                                    <?php if(Sentinel::hasAccess('loans.delete')): ?>
                                        <a type="button" class="btn bg-gray margin deleteLoan"
                                           href="<?php echo e(url('loan/'.$loan->id.'/delete')); ?>"><?php echo e(trans_choice('general.delete',1)); ?>

                                            <?php echo e(trans_choice('general.loan',1)); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="box-body no-padding">
                            <table class="table table-condensed">
                                <tbody>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.status',1)); ?></b>
                                    </td>
                                    <td>
                                        <?php if($loan->maturity_date<date("Y-m-d") && \App\Helpers\GeneralHelper::loan_total_balance($loan->id)>0): ?>
                                            <span class="label label-danger"><?php echo e(trans_choice('general.past_maturity',1)); ?></span>
                                        <?php else: ?>
                                            <?php if($loan->status=='pending'): ?>
                                                <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.approval',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='approved'): ?>
                                                <span class="label label-info"><?php echo e(trans_choice('general.awaiting',1)); ?> <?php echo e(trans_choice('general.disbursement',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='disbursed'): ?>
                                                <span class="label label-info"><?php echo e(trans_choice('general.active',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='declined'): ?>
                                                <span class="label label-danger"><?php echo e(trans_choice('general.declined',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='withdrawn'): ?>
                                                <span class="label label-danger"><?php echo e(trans_choice('general.withdrawn',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='written_off'): ?>
                                                <span class="label label-danger"><?php echo e(trans_choice('general.written_off',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='closed'): ?>
                                                <span class="label label-success"><?php echo e(trans_choice('general.closed',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='pending_reschedule'): ?>
                                                <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?> <?php echo e(trans_choice('general.reschedule',1)); ?></span>
                                            <?php endif; ?>
                                            <?php if($loan->status=='rescheduled'): ?>
                                                <span class="label label-info"><?php echo e(trans_choice('general.rescheduled',1)); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>

                                    <td width="200">
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.application',1)); ?> <?php echo e(trans_choice('general.id',1)); ?></b>
                                    </td>
                                    <td><?php echo e($loan->id); ?></td>

                                </tr>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.product',1)); ?></b>
                                    </td>
                                    <td>
                                        <?php if(!empty($loan->loan_product)): ?>
                                            <?php echo e($loan->loan_product->name); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="bg-navy disabled color-palette">
                                        <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.term',2)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td><b><?php echo e(trans_choice('general.disbursed_by',1)); ?></b></td>
                                    <td>
                                        <?php if(!empty($loan->loan_disbursed_by)): ?>
                                            <?php echo e($loan->loan_disbursed_by->name); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>

                                    <td>
                                        <b><?php echo e(trans_choice('general.principal',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></b>
                                    </td>
                                    <td><?php echo e(round($loan->principal,2)); ?></td>

                                </tr>
                                <tr>

                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.release',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></b>
                                    </td>
                                    <td><?php echo e($loan->release_date); ?></td>

                                </tr>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.method',1)); ?></b>
                                    </td>
                                    <td>
                                        <?php if($loan->interest_method=='declining_balance_equal_installments'): ?>
                                            <?php echo e(trans_choice('general.declining_balance_equal_installments',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->interest_method=='declining_balance_equal_principal'): ?>
                                            <?php echo e(trans_choice('general.declining_balance_equal_principal',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->interest_method=='interest_only'): ?>
                                            <?php echo e(trans_choice('general.interest_only',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->interest_method=='flat_rate'): ?>
                                            <?php echo e(trans_choice('general.flat_rate',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->interest_method=='compound_interest'): ?>
                                            <?php echo e(trans_choice('general.compound_interest',1)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.interest',1)); ?></b>
                                    </td>
                                    <td><?php echo e(round($loan->interest_rate,2)); ?>%/<?php echo e($loan->interest_period); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.duration',1)); ?></b>
                                    </td>
                                    <td><?php echo e($loan->loan_duration); ?> <?php echo e($loan->loan_duration_type); ?>s
                                    </td>
                                </tr>
                                <tr>
                                    <td><b><?php echo e(trans_choice('general.repayment_cycle',1)); ?></b></td>
                                    <td>
                                        <?php if($loan->repayment_cycle=='daily'): ?>
                                            <?php echo e(trans_choice('general.daily',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='weekly'): ?>
                                            <?php echo e(trans_choice('general.weekly',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='monthly'): ?>
                                            <?php echo e(trans_choice('general.monthly',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='bi_monthly'): ?>
                                            <?php echo e(trans_choice('general.bi_monthly',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='quarterly'): ?>
                                            <?php echo e(trans_choice('general.quarterly',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='semi_annual'): ?>
                                            <?php echo e(trans_choice('general.semi_annually',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->repayment_cycle=='annually'): ?>
                                            <?php echo e(trans_choice('general.annual',1)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>

                                <tr>
                                    <td><b><?php echo e(trans_choice('general.number',1)); ?>

                                            of <?php echo e(trans_choice('general.repayment',2)); ?></b></td>
                                    <td>
                                        <?php echo e(\App\Models\LoanSchedule::where('loan_id',$loan->id)->count()); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td><b><?php echo e(trans_choice('general.decimal_place',1)); ?></b></td>
                                    <td>
                                        <?php if($loan->decimal_places=='round_off_to_two_decimal'): ?>
                                            <?php echo e(trans_choice('general.round_off_to_two_decimal',1)); ?>

                                        <?php endif; ?>
                                        <?php if($loan->decimal_places=='round_off_to_integer'): ?>
                                            <?php echo e(trans_choice('general.round_off_to_integer',1)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b><?php echo e(trans_choice('general.first',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?> <?php echo e(trans_choice('general.date',1)); ?></b>
                                    </td>
                                    <td><?php echo e($loan->first_payment_date); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="bg-navy disabled color-palette">
                                        System Generated Penalties
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"
                                        class="bg-blue disabled color-palette"><?php echo e(trans_choice('general.late_repayment_penalty',1)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-red" colspan="2">
                                        <?php if($loan->loan_product->enable_late_repayment_penalty==1): ?>
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                                    <th><?php echo e(trans_choice('general.type',1)); ?></th>
                                                    <th><?php echo e(trans_choice('general.value',1)); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <?php if($loan->loan_product->late_repayment_penalty_calculate=='overdue_principal'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->late_repayment_penalty_calculate=='overdue_principal_interest'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal_interest',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->late_repayment_penalty_calculate=='overdue_principal_interest_fees'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal_interest_fees',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->late_repayment_penalty_calculate=='total_overdue'): ?>
                                                            <b><?php echo e(trans_choice('general.total_overdue',1)); ?></b>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($loan->loan_product->late_repayment_penalty_type); ?></td>
                                                    <td><?php echo e($loan->loan_product->late_repayment_penalty_amount); ?></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        <?php else: ?>
                                            <b><?php echo e(trans_choice('general.late_repayment_disabled',1)); ?></b>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                            <br><br>
                            <table class="table table-bordered table-hover">
                                <tbody>
                                <tr>
                                    <td colspan="2"
                                        class="bg-blue disabled color-palette"><?php echo e(trans_choice('general.after_maturity_date_penalty',1)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-red" colspan="2">
                                        <?php if($loan->loan_product->enable_after_maturity_date_penalty==1): ?>
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                                    <th><?php echo e(trans_choice('general.type',1)); ?></th>
                                                    <th><?php echo e(trans_choice('general.value',1)); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <?php if($loan->loan_product->after_maturity_date_penalty_calculate=='overdue_principal'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->after_maturity_date_penalty_calculate=='overdue_principal_interest'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal_interest',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->after_maturity_date_penalty_calculate=='overdue_principal_interest_fees'): ?>
                                                            <b><?php echo e(trans_choice('general.overdue_principal_interest_fees',1)); ?></b>
                                                        <?php endif; ?>
                                                        <?php if($loan->loan_product->after_maturity_date_penalty_calculate=='total_overdue'): ?>
                                                            <b><?php echo e(trans_choice('general.total_overdue',1)); ?></b>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($loan->loan_product->after_maturity_date_penalty_type); ?></td>
                                                    <td><?php echo e($loan->loan_product->after_maturity_date_penalty_amount); ?></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        <?php else: ?>
                                            <b><?php echo e(trans_choice('general.after_maturity_date_disabled',1)); ?></b>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="bg-navy disabled color-palette">
                                        <?php echo e(trans_choice('general.description',1)); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <?php if(!empty($loan->description)): ?>
                                            <?php echo e($loan->description); ?>

                                        <?php else: ?>
                                            <?php echo e(trans_choice('general.none',1)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="tab-pane" id="loan_collateral">
                        <div class="btn-group-horizontal">
                            <?php if(Sentinel::hasAccess('collateral.create')): ?>
                                <a type="button" class="btn bg-gray margin"
                                   href="<?php echo e(url('collateral/'.$loan->id.'/create?return_url='.Request::url())); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                                    <?php echo e(trans_choice('general.collateral',1)); ?></a>
                            <?php endif; ?>
                        </div>
                        <div class="box box-success">
                            <div class="table-responsive">
                                <table id="data-table" class="table table-bordered table-condensed table-hover">
                                    <thead>
                                    <tr style="background-color: #D1F9FF">
                                        <th><?php echo e(trans_choice('general.type',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.value',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.status',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.date',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($loan->collateral as $key): ?>
                                        <tr>
                                            <td>
                                                <?php if(!empty($key->collateral_type)): ?>
                                                    <?php echo e($key->collateral_type->name); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($key->name); ?></td>
                                            <td><?php echo e($key->value); ?></td>
                                            <td>
                                                <?php if($key->status=='deposited_into_branch'): ?>
                                                    <?php echo e(trans_choice('general.deposited_into_branch',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='collateral_with_borrower'): ?>
                                                    <?php echo e(trans_choice('general.collateral_with_borrower',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='returned_to_borrower'): ?>
                                                    <?php echo e(trans_choice('general.returned_to_borrower',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='repossession_initiated'): ?>
                                                    <?php echo e(trans_choice('general.repossession_initiated',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='repossessed'): ?>
                                                    <?php echo e(trans_choice('general.repossessed',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='sold'): ?>
                                                    <?php echo e(trans_choice('general.sold',1)); ?>

                                                <?php endif; ?>
                                                <?php if($key->status=='lost'): ?>
                                                    <?php echo e(trans_choice('general.lost',1)); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($key->date); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button"
                                                            class="btn btn-info btn-xs dropdown-toggle"
                                                            data-toggle="dropdown" aria-expanded="false">
                                                        <?php echo e(trans('general.choose')); ?> <span class="caret"></span>
                                                        <span class="sr-only">Toggle Dropdown</span>
                                                    </button>
                                                    <ul class="dropdown-menu" role="menu">
                                                        <?php if(Sentinel::hasAccess('collateral.view')): ?>
                                                            <li><a href="<?php echo e(url('collateral/'.$key->id.'/show')); ?>"><i
                                                                            class="fa fa-search"></i> <?php echo e(trans('general.view')); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                        <?php if(Sentinel::hasAccess('collateral.update')): ?>
                                                            <li><a href="<?php echo e(url('collateral/'.$key->id.'/edit')); ?>"><i
                                                                            class="fa fa-edit"></i> <?php echo e(trans('general.edit')); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                        <?php if(Sentinel::hasAccess('collateral.delete')): ?>
                                                            <li>
                                                                <a href="<?php echo e(url('collateral/'.$key->id.'/delete')); ?>"
                                                                   class="delete"><i
                                                                            class="fa fa-trash"></i> <?php echo e(trans('general.delete')); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="loan_guarantors">
                        <div class="btn-group-horizontal">
                            <?php if(Sentinel::hasAccess('loans.guarantor.create')): ?>
                                <a type="button" class="btn bg-gray margin"
                                   href="<?php echo e(url('loan/'.$loan->id.'/guarantor/create?return_url='.Request::url())); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                                    <?php echo e(trans_choice('general.guarantor',1)); ?></a>
                            <?php endif; ?>
                        </div>
                        <div class="box box-success">
                            <div class="table-responsive">
                                <table id="data-table" class="table table-bordered table-condensed table-hover">
                                    <thead>
                                    <tr style="background-color: #D1F9FF">
                                        <th><?php echo e(trans_choice('general.name',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.status',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.accepted',1)); ?> <?php echo e(trans_choice('general.amount',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.saving',2)); ?> <?php echo e(trans_choice('general.status',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.note',2)); ?></th>
                                        <th><?php echo e(trans_choice('general.date',1)); ?></th>
                                        <th><?php echo e(trans_choice('general.action',1)); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($loan->guarantors as $key): ?>
                                        <tr>
                                            <td>
                                                <?php if(!empty($key->guarantee)): ?>
                                                    <a href="<?php echo e(url('borrower/'.$key->guarantee->id.'/show')); ?>"><?php echo e($key->guarantee->first_name); ?> <?php echo e($key->guarantee->middle_name); ?> <?php echo e($key->guarantee->last_name); ?></a>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($key->status=='accepted'): ?>
                                                    <span class="label label-success"><?php echo e(trans_choice('general.accepted',1)); ?></span>
                                                <?php endif; ?>
                                                <?php if($key->status=='pending'): ?>
                                                    <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?></span>
                                                <?php endif; ?>
                                                <?php if($key->status=='declined'): ?>
                                                    <span class="label label-danger"><?php echo e(trans_choice('general.declined',1)); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($key->amount); ?></td>
                                            <td><?php echo e($key->accepted_amount); ?></td>
                                            <td>
                                                <?php if($key->saving_status=='hold'): ?>
                                                    <span class="label label-success"><?php echo e(trans_choice('general.withdrawn',1)); ?></span>
                                                <?php endif; ?>
                                                <?php if($key->saving_status=='pending'): ?>
                                                    <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?></span>
                                                <?php endif; ?>
                                                <?php if($key->saving_status=='restored'): ?>
                                                    <span class="label label-info"><?php echo e(trans_choice('general.restored',1)); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $key->notes; ?></td>
                                            <td><?php echo e($key->date); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button"
                                                            class="btn btn-info btn-xs dropdown-toggle"
                                                            data-toggle="dropdown" aria-expanded="false">
                                                        <?php echo e(trans('general.choose')); ?> <span class="caret"></span>
                                                        <span class="sr-only">Toggle Dropdown</span>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                                        <?php if($key->saving_status=='hold'): ?>
                                                            <?php if(Sentinel::hasAccess('loans.guarantor.savings')): ?>
                                                                <li>
                                                                    <a href="<?php echo e(url('loan/'.$loan->id.'/guarantor/'.$key->id.'/restore')); ?>"
                                                                       class="delete"><i
                                                                                class="fa fa-refresh"></i> <?php echo e(trans('general.restore')); ?> <?php echo e(trans_choice('general.saving',2)); ?>

                                                                    </a></li>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php if($key->saving_status=='pending' || $key->saving_status=='restored'): ?>
                                                            <?php if(Sentinel::hasAccess('loans.guarantor.savings')): ?>
                                                                <li>
                                                                    <a href="#" data-amount="<?php echo e($key->accepted_amount); ?>"
                                                                       data-loan="<?php echo e($key->loan_id); ?>"
                                                                       data-id="<?php echo e($key->id); ?>" data-toggle="modal"
                                                                       data-target="#withdrawSaving"><i
                                                                                class="fa fa-minus-circle"></i> <?php echo e(trans('general.withdraw')); ?> <?php echo e(trans_choice('general.saving',2)); ?>

                                                                    </a></li>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php if(Sentinel::hasAccess('loans.guarantor.view')): ?>
                                                            <li>
                                                                <a href="<?php echo e(url('borrower/'.$key->guarantor_id.'/show')); ?>"><i
                                                                            class="fa fa-search"></i> <?php echo e(trans('general.view')); ?> <?php echo e(trans_choice('general.guarantor',1)); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                        <?php if(Sentinel::hasAccess('loans.guarantor.update')): ?>
                                                            <li><a href="<?php echo e(url('loan/guarantor/'.$key->id.'/edit')); ?>"><i
                                                                            class="fa fa-edit"></i> <?php echo e(trans('general.edit')); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                        <?php if(Sentinel::hasAccess('loans.guarantor.delete')): ?>
                                                            <li>
                                                                <a href="<?php echo e(url('loan/'.$loan->id.'/guarantor/'.$key->id.'/delete')); ?>"
                                                                   class="delete"><i
                                                                            class="fa fa-trash"></i> <?php echo e(trans('general.delete')); ?>

                                                                </a></li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="loan_files">
                        <p>To add new loan files or remove existing files, pls click the <b>Loan Terms</b> tab and
                            then
                            <b>Edit Loan</b>.</p>
                        <ul class="" style="font-size:12px; padding-left:10px">

                            <?php foreach(unserialize($loan->files) as $key=>$value): ?>
                                <li><a href="<?php echo asset('uploads/'.$value); ?>"
                                       target="_blank"><?php echo $value; ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="tab-pane" id="loan_comments">
                        <div class="tab_content">
                            <div class="btn-group-horizontal">
                                <a type="button" class="btn bg-gray margin"
                                   href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/create')); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                                    <?php echo e(trans_choice('general.comment',2)); ?></a>
                            </div>
                            <br>

                            <div class="box-footer box-comments">
                                <?php foreach($loan->comments as $comment): ?>
                                    <div class="box-comment">
                                        <!-- User image -->
                                        <img src="<?php echo e(asset('assets/dist/img/user.png')); ?>"
                                             class="img-circle" alt="User Image">

                                        <div class="comment-text">
                                <span class="username">
                                    <?php if(!empty(\App\Models\User::find($comment->user_id))): ?>
                                        <?php echo e(\App\Models\User::find($comment->user_id)->first_name); ?> <?php echo e(\App\Models\User::find($comment->user_id)->last_name); ?>

                                    <?php endif; ?>

                                    <span class="text-muted pull-right">
                                        <?php echo e($comment->created_at); ?>

                                    </span>
                                </span><!-- /.username -->
                                            <?php echo $comment->notes; ?>

                                            <span class="text-muted pull-right">
            <div class="btn-group-horizontal">
                <a type="button" class="btn bg-white btn-xs text-bold"
                   href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/'.$comment->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?></a><a
                        type="button" class="btn bg-white btn-xs text-bold deleteComment"
                        href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/'.$comment->id.'/delete')); ?>"><?php echo e(trans_choice('general.delete',1)); ?></a>
            </div>
                                </span>
                                        </div>
                                        <!-- /.comment-text -->
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->
        </div>
    </div>
    <div class="modal fade" id="approveLoan">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.approve',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/approve'),'method'=>'post')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('approved_date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('approved_date',date("Y-m-d"),array('class'=>'form-control date-picker','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('approved_amount',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('approved_amount',$loan->principal,array('class'=>'form-control touchspin','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label( 'Notes',null,array('class'=>' control-label')); ?>

                            <?php echo Form::textarea('approved_notes','',array('class'=>'form-control','rows'=>'3')); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="disburseLoan">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.disburse',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/disburse'),'method'=>'post')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('disbursed_date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('disbursed_date',$loan->release_date,array('class'=>'form-control date-picker','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('first_payment_date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('first_payment_date',$loan->first_payment_date,array('class'=>'form-control date-picker',''=>'')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('loan_disbursed_by_id',"Disbursed By",array('class'=>' control-label')); ?>

                            <?php echo Form::select('loan_disbursed_by_id',$loan_disbursed_by,null,array('class'=>'form-control','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label( 'Notes',null,array('class'=>' control-label')); ?>

                            <?php echo Form::textarea('disbursed_notes','',array('class'=>'form-control','rows'=>'3')); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="declineLoan">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.decline',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/decline'),'method'=>'post')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('declined_date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('declined_date',date("Y-m-d"),array('class'=>'form-control date-picker','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label( 'Notes',null,array('class'=>' control-label')); ?>

                            <?php echo Form::textarea('declined_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="writeoffLoan">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.write_off',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/write_off'),'method'=>'post')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('written_off_date',date("Y-m-d"),array('class'=>'form-control date-picker','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label( 'Notes',null,array('class'=>' control-label')); ?>

                            <?php echo Form::textarea('written_off_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="withdrawLoan">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/withdraw'),'method'=>'post')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label('date',null,array('class'=>' control-label')); ?>

                            <?php echo Form::text('withdrawn_date',date("Y-m-d"),array('class'=>'form-control date-picker','required'=>'required')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label( 'Notes',null,array('class'=>' control-label')); ?>

                            <?php echo Form::textarea('withdrawn_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <div class="modal fade" id="withdrawSaving">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.saving',1)); ?></h4>
                </div>
                <?php echo Form::open(array('url' =>'','method'=>'post','id'=>'withdrawSavingForm')); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>'')); ?>

                        <?php echo Form::text('amount',null, array('class' => 'form-control touchspin', 'id'=>'accepted_amount','required'=>'')); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('date',trans_choice('general.date',2),array('class'=>'')); ?>

                        <?php echo Form::text('date',date("Y-m-d"), array('class' => 'form-control date-picker', 'placeholder'=>'','required'=>'')); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('time',trans_choice('general.time',2),array('class'=>'')); ?>

                        <?php echo Form::text('time',date("H:i"), array('class' => 'form-control time-picker', 'placeholder'=>'','required'=>'')); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('notes',trans_choice('general.note',2),array('class'=>'')); ?>

                        <?php echo Form::textarea('notes',null, array('class' => 'form-control', 'placeholder'=>'',)); ?>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                            data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatable/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/media/js/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script>

        $('#view-repayments').DataTable({
            dom: 'frtip',
            "paging": true,
            "lengthChange": true,
            "displayLength": 15,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "order": [[0, "asc"]],
            "columnDefs": [
                {"orderable": false, "targets": [4, 5]}
            ],
            "language": {
                "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
                "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
                "info": "<?php echo e(trans('general.info')); ?>",
                "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
                "search": "<?php echo e(trans('general.search')); ?>",
                "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
                "paginate": {
                    "first": "<?php echo e(trans('general.first')); ?>",
                    "last": "<?php echo e(trans('general.last')); ?>",
                    "next": "<?php echo e(trans('general.next')); ?>",
                    "previous": "<?php echo e(trans('general.previous')); ?>"
                }
            },
            responsive: false
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#withdrawSaving').on('shown.bs.modal', function (e) {
                var id = $(e.relatedTarget).data('id');
                var amount = $(e.relatedTarget).data('amount');
                var url = "<?php echo url('loan/'.$loan->id.'/guarantor'); ?>/" + id + "/withdraw";
                $(e.currentTarget).find("#withdrawSavingForm").attr('action', url);
                $(e.currentTarget).find("#accepted_amount").val(amount);
            });
            $('.deleteLoan').on('click', function (e) {
                e.preventDefault();
                var href = $(this).attr('href');
                swal({
                    title: '<?php echo e(trans_choice('general.are_you_sure',1)); ?>',
                    text: '<?php echo e(trans_choice('general.delete_loan_msg',1)); ?>',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(trans_choice('general.ok',1)); ?>',
                    cancelButtonText: '<?php echo e(trans_choice('general.cancel',1)); ?>'
                }).then(function () {
                    window.location = href;
                })
            });
            $('.deletePayment').on('click', function (e) {
                e.preventDefault();
                var href = $(this).attr('href');
                swal({
                    title: '<?php echo e(trans_choice('general.are_you_sure',1)); ?>',
                    text: '<?php echo e(trans_choice('general.delete_payment_msg',1)); ?>',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(trans_choice('general.ok',1)); ?>',
                    cancelButtonText: '<?php echo e(trans_choice('general.cancel',1)); ?>'
                }).then(function () {
                    window.location = href;
                })
            });
            $('.deleteComment').on('click', function (e) {
                e.preventDefault();
                var href = $(this).attr('href');
                swal({
                    title: '<?php echo e(trans_choice('general.are_you_sure',1)); ?>',
                    text: '',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(trans_choice('general.ok',1)); ?>',
                    cancelButtonText: '<?php echo e(trans_choice('general.cancel',1)); ?>'
                }).then(function () {
                    window.location = href;
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>