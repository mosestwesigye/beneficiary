<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.transaction',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">
                <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.transaction',2)); ?>

                <?php if(!empty($start_date)): ?>
                    for period: <b><?php echo e($start_date); ?> to <?php echo e($end_date); ?></b>
                <?php endif; ?>
            </h3>

            <div class="box-tools pull-right">
                <button class="btn btn-sm btn-info hidden-print" onclick="window.print()">Print</button>
            </div>
        </div>
        <div class="box-body hidden-print">
            <h4 class=""><?php echo e(trans_choice('general.date',1)); ?> <?php echo e(trans_choice('general.range',1)); ?></h4>
            <?php echo Form::open(array('url' => Request::url(), 'method' => 'post','class'=>'form-horizontal', 'name' => 'form')); ?>

            <div class="row">
                <div class="col-xs-5">
                    <?php echo Form::text('start_date',null, array('class' => 'form-control date-picker', 'placeholder'=>"From Date",'required'=>'required')); ?>

                </div>
                <div class="col-xs-1  text-center" style="padding-top: 5px;">
                    to
                </div>
                <div class="col-xs-5">
                    <?php echo Form::text('end_date',null, array('class' => 'form-control date-picker', 'placeholder'=>"To Date",'required'=>'required')); ?>

                </div>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-xs-2">
                        <span class="input-group-btn">
                          <button type="submit" class="btn bg-olive btn-flat"><?php echo e(trans_choice('general.search',1)); ?>!
                          </button>
                        </span>
                        <span class="input-group-btn">
                          <a href="<?php echo e(Request::url()); ?>"
                             class="btn bg-purple  btn-flat pull-right"><?php echo e(trans_choice('general.reset',1)); ?>!</a>
                        </span>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>


        </div>
        <!-- /.box-body -->

    </div>
    <!-- /.box -->
    <div class="box box-info">
        <div class="box-body table-responsive no-padding">

            <table id="view-repayments"
                   class="table table-bordered table-condensed table-hover dataTable no-footer">
                <thead>
                <tr style="background-color: #D1F9FF" role="row">
                    <th>
                        <?php echo e(trans_choice('general.collection',1)); ?> <?php echo e(trans_choice('general.date',1)); ?>

                    </th>
                    <th><?php echo e(trans_choice('general.loan',1)); ?>#</th>
                    <th>
                        <?php echo e(trans_choice('general.borrower',1)); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('general.collected_by',1)); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('general.method',1)); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('general.amount',1)); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('general.action',1)); ?>

                    </th>
                    <th>
                        <?php echo e(trans_choice('general.receipt',1)); ?>

                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $amount=0; ?>
                <?php foreach($data as $key): ?>
                    <?php $amount=$amount+$key->amount; ?>
                    <tr>
                        <td><?php echo e($key->collection_date); ?></td>
                        <td><?php echo e($key->loan_id); ?></td>
                        <td>
                            <?php if(!empty($key->borrower)): ?>
                                <a href="<?php echo e(url('borrower/'.$key->borrower->id.'/show')); ?>"> <?php echo e($key->borrower->first_name); ?> <?php echo e($key->borrower->last_name); ?></a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!empty($key->user)): ?>
                                <?php echo e($key->user->first_name); ?> <?php echo e($key->user->last_name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!empty($key->loan_repayment_method)): ?>
                                <?php echo e($key->loan_repayment_method->name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e(round($key->amount,2)); ?></td>
                        <td>
                            <div class="btn-group-horizontal">
                                <?php if(Sentinel::hasAccess('repayments.update')): ?>
                                    <a type="button" class="btn bg-white btn-xs text-bold"
                                       href="<?php echo e(url('loan/'.$key->loan_id.'/repayment/'.$key->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?></a>
                                <?php endif; ?>
                                <?php if(Sentinel::hasAccess('repayments.delete')): ?>
                                    <a type="button"
                                       class="btn bg-white btn-xs text-bold deletePayment"
                                       href="<?php echo e(url('loan/'.$key->loan_id.'/repayment/'.$key->id.'/delete')); ?>"
                                            ><?php echo e(trans_choice('general.delete',1)); ?></a>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <a type="button" class="btn btn-default btn-xs"
                               href="<?php echo e(url('loan/'.$key->loan_id.'/repayment/'.$key->id.'/print')); ?>"
                               target="_blank">
                                                                <span class="glyphicon glyphicon-print"
                                                                      aria-hidden="true"></span>
                            </a>
                            <a type="button" class="btn btn-default btn-xs"
                               href="<?php echo e(url('loan/'.$key->loan_id.'/repayment/'.$key->id.'/pdf')); ?>"
                               target="_blank">
                                                                <span class="glyphicon glyphicon-file"
                                                                      aria-hidden="true"></span>
                            </a></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                        <?php if(\App\Models\Setting::where('setting_key', 'currency_position')->first()->setting_value=='left'): ?>
                            <b>  <?php echo e(\App\Models\Setting::where('setting_key', 'currency_symbol')->first()->setting_value); ?> <?php echo e(round($amount,2)); ?></b>
                        <?php else: ?>
                            <b><?php echo e(round($amount,2)); ?> <?php echo e(\App\Models\Setting::where('setting_key', 'currency_symbol')->first()->setting_value); ?></b>
                        <?php endif; ?>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>